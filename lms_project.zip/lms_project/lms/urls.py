from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),

    # Authentication
    path("register/", views.register, name="register"),
    path("login/", auth_views.LoginView.as_view(template_name="registration/login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),

    # Student
    path("dashboard/", views.dashboard, name="dashboard"),
    path("courses/", views.course_list, name="course_list"),
    path("courses/<int:pk>/", views.course_detail, name="course_detail"),
    path("courses/<int:pk>/enroll/", views.enroll, name="enroll"),
    path("quiz/<int:pk>/", views.quiz_take, name="quiz_take"),
    path("results/", views.my_results, name="my_results"),
    path("results/<int:pk>/", views.result_detail, name="result_detail"),

    # Administrator (staff only)
    path("manage/", views.manage_dashboard, name="manage_dashboard"),
    path("manage/courses/new/", views.course_create, name="course_create"),
    path("manage/courses/<int:pk>/edit/", views.course_edit, name="course_edit"),
    path("manage/courses/<int:pk>/delete/", views.course_delete, name="course_delete"),
    path("manage/courses/<int:pk>/material/", views.material_add, name="material_add"),
    path("manage/courses/<int:pk>/quiz/new/", views.quiz_create, name="quiz_create"),
    path("manage/quiz/<int:pk>/", views.quiz_manage, name="quiz_manage"),
    path("manage/quiz/<int:pk>/delete/", views.quiz_delete, name="quiz_delete"),
    path("manage/question/<int:pk>/delete/", views.question_delete, name="question_delete"),
    path("manage/attempts/", views.all_attempts, name="all_attempts"),
]
