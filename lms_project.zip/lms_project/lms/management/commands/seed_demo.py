from django.contrib.auth.models import User
from django.core.management.base import BaseCommand

from lms.models import Course, CourseMaterial, Question, Quiz


class Command(BaseCommand):
    help = "Create demo users, a course, study material and a quiz."

    def handle(self, *args, **options):
        if not User.objects.filter(username="admin").exists():
            User.objects.create_superuser("admin", "admin@example.com", "Admin@12345")
            self.stdout.write("Created administrator: admin / Admin@12345")
        if not User.objects.filter(username="student1").exists():
            User.objects.create_user("student1", "student1@example.com", "Student@12345", first_name="Demo Student")
            self.stdout.write("Created student: student1 / Student@12345")

        course, created = Course.objects.get_or_create(
            title="Python Programming Basics",
            defaults={
                "description": "Learn variables, control flow, functions and data structures in Python.",
                "instructor": "Mohamed Farook",
            },
        )
        if created:
            CourseMaterial.objects.create(
                course=course, title="Lesson 1: Variables and data types",
                content="A variable stores a value.\nPython has int, float, str, bool, list, tuple, dict and set types.")
            CourseMaterial.objects.create(
                course=course, title="Lesson 2: Control flow",
                content="Use if, elif and else for decisions.\nUse for and while for loops.")
            quiz = Quiz.objects.create(course=course, title="Python Basics Quiz 1", pass_percentage=50)
            data = [
                ("Which keyword defines a function in Python?", "func", "def", "define", "lambda", "B"),
                ("Which of these is a mutable data type?", "tuple", "str", "list", "int", "C"),
                ("What does len([1, 2, 3]) return?", "2", "3", "4", "Error", "B"),
                ("Which symbol starts a single-line comment?", "//", "#", "--", "/*", "B"),
            ]
            for text, a, b, c, d, correct in data:
                Question.objects.create(quiz=quiz, text=text, option_a=a, option_b=b,
                                        option_c=c, option_d=d, correct_option=correct, marks=1)
        self.stdout.write(self.style.SUCCESS("Demo data ready."))
