from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.db import transaction
from django.db.models import Avg, Count
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import (CourseForm, MaterialForm, QuestionForm, QuizForm,
                    RegisterForm)
from .models import (AttemptAnswer, Course, Enrollment, Question, Quiz,
                     QuizAttempt)

# Server-side permission check: used on every administrator view.
staff_required = user_passes_test(lambda u: u.is_authenticated and u.is_staff, login_url="login")


# --------------------------------------------------------------------------
# Public & authentication
# --------------------------------------------------------------------------
def home(request):
    context = {
        "course_count": Course.objects.count(),
        "quiz_count": Quiz.objects.count(),
        "featured": Course.objects.annotate(n=Count("enrollments")).order_by("-n", "-created_at")[:3],
    }
    return render(request, "lms/home.html", context)


def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Account created. Welcome aboard!")
        return redirect("dashboard")
    return render(request, "registration/register.html", {"form": form})


# --------------------------------------------------------------------------
# Student views
# --------------------------------------------------------------------------
@login_required
def dashboard(request):
    if request.user.is_staff:
        return redirect("manage_dashboard")

    enrollments = (Enrollment.objects.filter(student=request.user)
                   .select_related("course").prefetch_related("course__quizzes"))
    attempts = QuizAttempt.objects.filter(student=request.user).select_related("quiz", "quiz__course")

    progress_rows = []
    for enr in enrollments:
        quizzes = list(enr.course.quizzes.all())
        done_ids = set(attempts.filter(quiz__course=enr.course).values_list("quiz_id", flat=True))
        done = len([q for q in quizzes if q.id in done_ids])
        percent = round(done * 100 / len(quizzes)) if quizzes else 0
        progress_rows.append({"course": enr.course, "done": done, "total": len(quizzes), "percent": percent})

    context = {
        "progress_rows": progress_rows,
        "recent": attempts[:5],
        "attempt_count": attempts.count(),
        "avg_score": attempts.aggregate(a=Avg("score"))["a"],
    }
    return render(request, "lms/dashboard.html", context)


def course_list(request):
    query = request.GET.get("q", "").strip()
    courses = Course.objects.all()
    if query:
        courses = courses.filter(title__icontains=query)
    enrolled_ids = set()
    if request.user.is_authenticated:
        enrolled_ids = set(Enrollment.objects.filter(student=request.user).values_list("course_id", flat=True))
    return render(request, "lms/course_list.html", {"courses": courses, "query": query, "enrolled_ids": enrolled_ids})


def course_detail(request, pk):
    course = get_object_or_404(Course, pk=pk)
    enrolled = request.user.is_authenticated and Enrollment.objects.filter(student=request.user, course=course).exists()
    can_view = enrolled or (request.user.is_authenticated and request.user.is_staff)
    attempted = set()
    if request.user.is_authenticated:
        attempted = set(QuizAttempt.objects.filter(student=request.user, quiz__course=course).values_list("quiz_id", flat=True))
    context = {
        "course": course,
        "enrolled": enrolled,
        "can_view": can_view,
        "materials": course.materials.all() if can_view else [],
        "quizzes": course.quizzes.annotate(qn=Count("questions")),
        "attempted": attempted,
    }
    return render(request, "lms/course_detail.html", context)


@login_required
@require_POST
def enroll(request, pk):
    course = get_object_or_404(Course, pk=pk)
    _, created = Enrollment.objects.get_or_create(student=request.user, course=course)
    messages.success(request, f"You are now enrolled in {course.title}." if created else "You are already enrolled in this course.")
    return redirect("course_detail", pk=pk)


@login_required
def quiz_take(request, pk):
    quiz = get_object_or_404(Quiz.objects.select_related("course"), pk=pk)
    questions = list(quiz.questions.all())

    if not Enrollment.objects.filter(student=request.user, course=quiz.course).exists() and not request.user.is_staff:
        messages.error(request, "Enroll in this course before attempting its quizzes.")
        return redirect("course_detail", pk=quiz.course_id)

    if not questions:
        messages.error(request, "This quiz has no questions yet.")
        return redirect("course_detail", pk=quiz.course_id)

    previous = QuizAttempt.objects.filter(student=request.user, quiz=quiz).first()
    if previous and not quiz.allow_retake:
        messages.error(request, "Retakes are turned off for this quiz. Here is your result.")
        return redirect("result_detail", pk=previous.pk)

    if request.method == "POST":
        # Marks are always calculated on the server, never taken from the browser.
        with transaction.atomic():
            attempt = QuizAttempt.objects.create(student=request.user, quiz=quiz, total_marks=sum(q.marks for q in questions))
            score = 0
            for q in questions:
                selected = request.POST.get(f"q_{q.id}", "").upper()
                if selected not in ("A", "B", "C", "D"):
                    selected = ""
                correct = selected == q.correct_option
                if correct:
                    score += q.marks
                AttemptAnswer.objects.create(attempt=attempt, question=q, selected_option=selected, is_correct=correct)
            attempt.score = score
            attempt.save(update_fields=["score"])
        messages.success(request, "Quiz submitted. Your result is saved.")
        return redirect("result_detail", pk=attempt.pk)

    return render(request, "lms/quiz_take.html", {"quiz": quiz, "questions": questions, "previous": previous})


@login_required
def my_results(request):
    attempts = QuizAttempt.objects.filter(student=request.user).select_related("quiz", "quiz__course")
    return render(request, "lms/my_results.html", {"attempts": attempts})


@login_required
def result_detail(request, pk):
    attempt = get_object_or_404(QuizAttempt.objects.select_related("quiz", "quiz__course", "student"), pk=pk)
    # Students may only see their own results; staff may see all.
    if attempt.student_id != request.user.id and not request.user.is_staff:
        messages.error(request, "You can only view your own results.")
        return redirect("my_results")
    answers = attempt.answers.select_related("question")
    return render(request, "lms/result_detail.html", {"attempt": attempt, "answers": answers})


# --------------------------------------------------------------------------
# Administrator views
# --------------------------------------------------------------------------
@staff_required
def manage_dashboard(request):
    context = {
        "student_count": User.objects.filter(is_staff=False).count(),
        "course_count": Course.objects.count(),
        "quiz_count": Quiz.objects.count(),
        "attempt_count": QuizAttempt.objects.count(),
        "courses": Course.objects.annotate(students=Count("enrollments", distinct=True), quiz_total=Count("quizzes", distinct=True)),
        "recent": QuizAttempt.objects.select_related("student", "quiz")[:8],
    }
    return render(request, "lms/manage_dashboard.html", context)


@staff_required
def course_create(request):
    form = CourseForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        course = form.save()
        messages.success(request, "Course created.")
        return redirect("course_detail", pk=course.pk)
    return render(request, "lms/form_page.html", {"form": form, "heading": "New course", "submit": "Create course"})


@staff_required
def course_edit(request, pk):
    course = get_object_or_404(Course, pk=pk)
    form = CourseForm(request.POST or None, instance=course)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Course updated.")
        return redirect("course_detail", pk=pk)
    return render(request, "lms/form_page.html", {"form": form, "heading": f"Edit {course.title}", "submit": "Save changes"})


@staff_required
def course_delete(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.method == "POST":
        course.delete()
        messages.success(request, "Course deleted.")
        return redirect("manage_dashboard")
    return render(request, "lms/confirm_delete.html", {"obj": course, "kind": "course", "back": "course_detail", "back_pk": pk})


@staff_required
def material_add(request, pk):
    course = get_object_or_404(Course, pk=pk)
    form = MaterialForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        material = form.save(commit=False)
        material.course = course
        material.save()
        messages.success(request, "Study material added.")
        return redirect("course_detail", pk=pk)
    return render(request, "lms/form_page.html", {"form": form, "heading": f"Add material to {course.title}", "submit": "Add material"})


@staff_required
def quiz_create(request, pk):
    course = get_object_or_404(Course, pk=pk)
    form = QuizForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        quiz = form.save(commit=False)
        quiz.course = course
        quiz.save()
        messages.success(request, "Quiz created. Now add its questions.")
        return redirect("quiz_manage", pk=quiz.pk)
    return render(request, "lms/form_page.html", {"form": form, "heading": f"New quiz for {course.title}", "submit": "Create quiz"})


@staff_required
def quiz_manage(request, pk):
    quiz = get_object_or_404(Quiz.objects.select_related("course"), pk=pk)
    form = QuestionForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        question = form.save(commit=False)
        question.quiz = quiz
        question.save()
        messages.success(request, "Question added.")
        return redirect("quiz_manage", pk=pk)
    return render(request, "lms/quiz_manage.html", {"quiz": quiz, "questions": quiz.questions.all(), "form": form})


@staff_required
def quiz_delete(request, pk):
    quiz = get_object_or_404(Quiz, pk=pk)
    course_id = quiz.course_id
    if request.method == "POST":
        quiz.delete()
        messages.success(request, "Quiz deleted.")
        return redirect("course_detail", pk=course_id)
    return render(request, "lms/confirm_delete.html", {"obj": quiz, "kind": "quiz", "back": "quiz_manage", "back_pk": pk})


@staff_required
@require_POST
def question_delete(request, pk):
    question = get_object_or_404(Question, pk=pk)
    quiz_id = question.quiz_id
    question.delete()
    messages.success(request, "Question removed.")
    return redirect("quiz_manage", pk=quiz_id)


@staff_required
def all_attempts(request):
    attempts = QuizAttempt.objects.select_related("student", "quiz", "quiz__course")
    return render(request, "lms/all_attempts.html", {"attempts": attempts})
