from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Course, CourseMaterial, Question, Quiz


class RegisterForm(UserCreationForm):
    first_name = forms.CharField(max_length=60, required=True, label="Full name")
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ("username", "first_name", "email", "password1", "password2")

    def clean_email(self):
        email = self.cleaned_data["email"].lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email


class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ("title", "description", "instructor")
        widgets = {"description": forms.Textarea(attrs={"rows": 5})}


class MaterialForm(forms.ModelForm):
    class Meta:
        model = CourseMaterial
        fields = ("title", "content")
        widgets = {"content": forms.Textarea(attrs={"rows": 6})}


class QuizForm(forms.ModelForm):
    class Meta:
        model = Quiz
        fields = ("title", "pass_percentage", "allow_retake")

    def clean_pass_percentage(self):
        value = self.cleaned_data["pass_percentage"]
        if not 1 <= value <= 100:
            raise forms.ValidationError("Enter a value between 1 and 100.")
        return value


class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ("text", "option_a", "option_b", "option_c", "option_d", "correct_option", "marks")
        widgets = {"text": forms.Textarea(attrs={"rows": 3})}

    def clean_marks(self):
        value = self.cleaned_data["marks"]
        if value < 1:
            raise forms.ValidationError("Marks must be at least 1.")
        return value
