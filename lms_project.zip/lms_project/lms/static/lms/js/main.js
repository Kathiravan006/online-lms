// Mobile menu toggle
(function () {
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  // Quiz page: live "answered" counter and unanswered-question confirmation.
  // Marks are still calculated on the server; this is only a convenience.
  var form = document.getElementById("quiz-form");
  if (form) {
    var total = parseInt(form.dataset.total, 10) || 0;
    var counter = document.getElementById("answered");

    function answeredCount() {
      var names = {};
      form.querySelectorAll("input[type=radio]:checked").forEach(function (r) { names[r.name] = true; });
      return Object.keys(names).length;
    }

    form.addEventListener("change", function () {
      if (counter) counter.textContent = answeredCount();
    });

    form.addEventListener("submit", function (e) {
      var left = total - answeredCount();
      var msg = left > 0
        ? left + " question(s) are unanswered. Submit anyway?"
        : "Submit your answers now? You cannot change them after submitting.";
      if (!window.confirm(msg)) e.preventDefault();
    });
  }
})();
