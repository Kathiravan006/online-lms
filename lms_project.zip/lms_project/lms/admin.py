from django.contrib import admin

from .models import (AttemptAnswer, Course, CourseMaterial, Enrollment,
                     Question, Quiz, QuizAttempt)


class MaterialInline(admin.TabularInline):
    model = CourseMaterial
    extra = 0


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ("title", "instructor", "created_at")
    search_fields = ("title", "instructor")
    inlines = [MaterialInline]


class QuestionInline(admin.StackedInline):
    model = Question
    extra = 1


@admin.register(Quiz)
class QuizAdmin(admin.ModelAdmin):
    list_display = ("title", "course", "pass_percentage", "allow_retake")
    list_filter = ("course",)
    inlines = [QuestionInline]


@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ("student", "course", "enrolled_at")
    list_filter = ("course",)


@admin.register(QuizAttempt)
class QuizAttemptAdmin(admin.ModelAdmin):
    list_display = ("student", "quiz", "score", "total_marks", "submitted_at")
    list_filter = ("quiz",)


admin.site.register(AttemptAnswer)
