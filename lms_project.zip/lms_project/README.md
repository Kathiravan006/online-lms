# Online Learning Management System (Django + MySQL)

Full stack LMS: students browse and enroll in courses, read material, take quizzes and see marks and progress. Administrators manage courses, material, quizzes and view all results.

## Tech stack
Python, Django (MVT), MySQL, HTML, CSS, JavaScript.

## Setup (Windows / Linux / macOS)
```
python -m venv venv
venv\Scripts\activate          # Linux/macOS: source venv/bin/activate
pip install -r requirements.txt
```

### Option A: MySQL (as in the report)
1. Create the database in MySQL:
   `CREATE DATABASE lms_db CHARACTER SET utf8mb4;`
2. Set environment variables (or edit `lms_project/settings.py`):
   `DB_NAME=lms_db  DB_USER=root  DB_PASSWORD=yourpassword  DB_HOST=127.0.0.1  DB_PORT=3306`
   Windows: `set DB_PASSWORD=yourpassword`   Linux/macOS: `export DB_PASSWORD=yourpassword`

### Option B: quick start with SQLite (no MySQL needed)
Windows: `set USE_SQLITE=1`   Linux/macOS: `export USE_SQLITE=1`

### Then run
```
python manage.py makemigrations lms
python manage.py migrate
python manage.py seed_demo
python manage.py runserver
```
Open http://127.0.0.1:8000/

Demo logins created by `seed_demo`:
- Administrator: `admin` / `Admin@12345`
- Student: `student1` / `Student@12345`
(Change these passwords before any real use.)

## Features
- Registration, login, logout (Django auth, hashed passwords, CSRF protection)
- Role based access: student pages vs staff-only management pages (checked in the views)
- Course list with search, course detail, enrollment
- Study material per course (visible to enrolled students)
- Quizzes with multiple choice questions, server side score calculation, saved attempts
- Result page with answer review, My results page
- Student dashboard: enrolled courses, progress (quizzes attempted / total), recent marks
- Administrator dashboard: counts, courses, latest attempts, all results
- Django admin site at /admin/ for bulk data management

## Project structure
```
lms_project/        settings, root urls, wsgi/asgi
lms/models.py       Course, CourseMaterial, Enrollment, Quiz, Question, QuizAttempt, AttemptAnswer
lms/views.py        all views and permission checks
lms/forms.py        registration, course, quiz and question forms
lms/urls.py         URL routes
lms/templates/      HTML templates
lms/static/lms/     CSS and JavaScript
```

## Database tables
Users (Django auth_user), Courses, CourseMaterial, Enrollments, Quizzes, Questions, QuizAttempts, AttemptAnswers.
Relations: Course 1-N Quiz, Quiz 1-N Question, User 1-N QuizAttempt, User N-N Course through Enrollment.
